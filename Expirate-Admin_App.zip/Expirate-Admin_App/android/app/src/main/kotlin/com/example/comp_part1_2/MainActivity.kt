package com.example.comp_part1_2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
