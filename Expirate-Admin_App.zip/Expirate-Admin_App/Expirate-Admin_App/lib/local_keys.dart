abstract class LocaleKeys {
  static const main_title = 'main.title';
  static const main_bodytext = 'main.bodytext';
  static const main = 'main';
}